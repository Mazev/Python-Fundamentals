from classes_and_objects_demo.owner import Owner
from classes_and_objects_demo.cat import Cat

cats = []
owners = []

for num in range(0, 20):
    cat = Cat("name" + str(num), num)
    cats.append(cat)

for num in range(0, 20):
    o = Owner("name" + str(num))
    o.animals.append(cats[num])
    owners.append(o)
print(owners[5].animals)