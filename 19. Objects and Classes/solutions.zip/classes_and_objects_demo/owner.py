class Owner:
    def __init__(self, name):
        self.name = name
        self.animals = []

    def take_animal(self, animal):
        self.animals.append(animal)
        a = 5
